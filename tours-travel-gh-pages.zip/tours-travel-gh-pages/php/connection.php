<?php
$con=mysql_connect("127.0.0.1","root","");
$db=mysql_select_db("trip_advisor",$con);
?>
